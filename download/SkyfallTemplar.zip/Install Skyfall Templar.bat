@echo off
rem Double-click this to install Skyfall Templar with a desktop icon.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0install.ps1"
