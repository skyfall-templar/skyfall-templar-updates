#!/bin/bash
# Builds "Skyfall Templar.app" in your Applications folder.
# The app opens the game in its own window (Chrome, Edge or Brave app mode), or in Safari if none of those is installed.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/Applications/Skyfall Templar.app"

mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$HERE/Skyfall Templar.html" "$APP/Contents/Resources/"
cp "$HERE/skyfall.icns" "$APP/Contents/Resources/"

cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Skyfall Templar</string>
  <key>CFBundleDisplayName</key><string>Skyfall Templar</string>
  <key>CFBundleIdentifier</key><string>com.skyfalltemplar.game</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>launch</string>
  <key>CFBundleIconFile</key><string>skyfall</string>
</dict></plist>
PLIST

cat > "$APP/Contents/MacOS/launch" <<'LAUNCH'
#!/bin/bash
GAME="$(cd "$(dirname "$0")/../Resources" && pwd)/Skyfall Templar.html"
URL="file://$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$GAME" 2>/dev/null || echo "$GAME")"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser"; do
  if [ -d "/Applications/$B.app" ] || [ -d "$HOME/Applications/$B.app" ]; then
    exec open -na "$B" --args --app="$URL"
  fi
done
exec open -a Safari "$GAME"
LAUNCH
chmod +x "$APP/Contents/MacOS/launch"
touch "$APP"

echo ""
echo "Skyfall Templar is installed in your Applications folder."
echo "Drag it to the Dock to keep it handy. Opening it now..."
open "$APP"
