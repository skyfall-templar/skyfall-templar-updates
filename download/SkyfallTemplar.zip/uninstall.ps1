# Removes Skyfall Templar and its shortcuts. Your save game stays in the browser.
Add-Type -AssemblyName System.Windows.Forms
$game = 'Skyfall Templar'
$ok = [System.Windows.Forms.MessageBox]::Show("Remove Skyfall Templar from this computer?", $game, 'YesNo', 'Question')
if ($ok -ne 'Yes') { exit }
$programs = [Environment]::GetFolderPath('Programs')
Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Desktop')) "$game.lnk")
Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $programs "$game.lnk")
Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $programs "Uninstall $game.lnk")
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue (Join-Path $env:LOCALAPPDATA $game)
[System.Windows.Forms.MessageBox]::Show("Skyfall Templar has been removed.", $game, 'OK', 'Information') | Out-Null
