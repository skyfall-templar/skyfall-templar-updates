# Installs Skyfall Templar for the current user and adds desktop + Start menu shortcuts.
# The shortcut opens the game in its own window (Microsoft Edge or Google Chrome "app" mode, no browser bars).

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$game   = 'Skyfall Templar'
$src    = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest   = Join-Path $env:LOCALAPPDATA $game
$html   = Join-Path $dest 'Skyfall Templar.html'
$icon   = Join-Path $dest 'skyfall.ico'

try {
    # 1. Copy the game
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Copy-Item -Force (Join-Path $src 'Skyfall Templar.html') $html
    Copy-Item -Force (Join-Path $src 'skyfall.ico') $icon
    Copy-Item -Force (Join-Path $src 'uninstall.ps1') (Join-Path $dest 'uninstall.ps1')

    # 2. Find a browser that can open it as an app window
    $candidates = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    $browser = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
    if (-not $browser) {
        foreach ($exe in 'msedge.exe', 'chrome.exe') {
            $key = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe"
            if (Test-Path $key) { $browser = (Get-ItemProperty $key).'(default)'; if ($browser) { break } }
        }
    }

    $url = ([System.Uri]$html).AbsoluteUri

    # 3. Make the shortcuts
    $shell = New-Object -ComObject WScript.Shell
    $places = @(
        [Environment]::GetFolderPath('Desktop'),
        [Environment]::GetFolderPath('Programs')
    )
    foreach ($dir in $places) {
        $lnk = $shell.CreateShortcut((Join-Path $dir "$game.lnk"))
        if ($browser) {
            $lnk.TargetPath = $browser
            $lnk.Arguments  = "--app=`"$url`" --start-maximized"
        } else {
            # No Edge or Chrome: open in the default browser instead
            $lnk.TargetPath = $html
        }
        $lnk.WorkingDirectory = $dest
        $lnk.IconLocation     = "$icon,0"
        $lnk.Description      = 'Play Skyfall Templar'
        $lnk.Save()
    }

    # Uninstall entry in the Start menu
    $un = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) "Uninstall $game.lnk"))
    $un.TargetPath = 'powershell.exe'
    $un.Arguments  = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dest\uninstall.ps1`""
    $un.IconLocation = "$icon,0"
    $un.Save()

    $msg = "Skyfall Templar is installed.`n`nDouble-click the Skyfall Templar icon on your desktop to play.`n`nPlay now?"
    $answer = [System.Windows.Forms.MessageBox]::Show($msg, $game, 'YesNo', 'Information')
    if ($answer -eq 'Yes') {
        if ($browser) { Start-Process -FilePath $browser -ArgumentList "--app=`"$url`"", '--start-maximized' }
        else { Start-Process -FilePath $html }
    }
}
catch {
    [System.Windows.Forms.MessageBox]::Show("Install failed: $($_.Exception.Message)", $game, 'OK', 'Error') | Out-Null
    exit 1
}
